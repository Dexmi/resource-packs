![icon](https://i.imgur.com/HHa3Tfs.png)


## Resizable
![resizable](https://i.imgur.com/gKYy5UE.png)
![resizable](https://i.imgur.com/N33jsML.png)

## Fixed
![resizable](https://i.imgur.com/cT7Xqvx.png)

Big thanks to Melky for having the patience to deal with my garbage Git skills.
Thank you to sgfost and EXpoZuR for creating the such great skins, having such great sprites, and giving me the inspiration to get this done.
