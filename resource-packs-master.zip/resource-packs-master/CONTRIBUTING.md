Plugin contributions should be formatted following the Runelite codestyle

https://github.com/runelite/runelite/wiki/Code-Conventions